/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo, ChangeEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Play, 
  Plus, 
  Info, 
  Search, 
  Bell, 
  ChevronRight, 
  ChevronLeft,
  Check,
  Facebook,
  Instagram,
  Twitter,
  Youtube,
  X,
  Edit2,
  Camera
} from 'lucide-react';
import { MOVIES, Movie } from './constants';
import { cn } from './lib/utils';

// --- Types ---

interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  isChild: boolean;
}

const DEFAULT_PROFILES: UserProfile[] = [
  { id: '1', name: 'User 1', avatar: 'https://upload.wikimedia.org/wikipedia/commons/0/0b/Netflix-avatar.png', isChild: false },
  { id: '2', name: 'User 2', avatar: 'https://occ-0-358-3187.1.nflxso.net/dnm/api/v6/K6hjPJd6cR6FpVELC5Pd6ovHRSk/AAAABY5cwEuc6SssqS-0yYm18E66vR47p2N-gY0V9iO5j7zF_J-qXyU_Yp7J0t9_Zk8v-vS6Y6Q_Q3l7GqY_9lXG4z-H.png?r=229', isChild: false },
  { id: '3', name: 'Kids', avatar: 'https://occ-0-358-3187.1.nflxso.net/dnm/api/v6/K6hjPJd6cR6FpVELC5Pd6ovHRSk/AAAABZpEis_LqXm_5_X9XyG3u_X7V_Y7_n8_B6i8_R5X8Xy7_R5X_R5X8X_R5X_R5X8X_R5X_R5X.png?r=1d3', isChild: true },
];

// --- Shared Components ---

function ProfileCard({ 
  profile, 
  isManageMode, 
  onSelect, 
  onEdit 
}: { 
  profile: UserProfile; 
  isManageMode: boolean; 
  onSelect: (p: UserProfile) => void;
  onEdit: (p: UserProfile) => void;
  key?: React.Key;
}) {
  return (
    <div className="flex flex-col items-center gap-4 group">
      <div 
        onClick={() => isManageMode ? onEdit(profile) : onSelect(profile)}
        className="relative cursor-pointer"
      >
        <motion.div 
          whileHover={{ scale: 1.05 }}
          className={cn(
            "w-24 h-24 md:w-32 md:h-32 rounded-md overflow-hidden border-2 border-transparent group-hover:border-white transition-all",
            isManageMode && "brightness-50"
          )}
        >
          <img 
            src={profile.avatar} 
            alt={profile.name} 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </motion.div>
        {isManageMode && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="p-2 border border-white rounded-full bg-black/40">
              <Edit2 size={24} className="text-white" />
            </div>
          </div>
        )}
      </div>
      <span className="text-gray-400 group-hover:text-white text-lg md:text-xl transition-colors">
        {profile.name}
      </span>
    </div>
  );
}

function MovieCard({ 
  movie, 
  onAddToList, 
  isInList,
  onInfoClick
}: { 
  movie: Movie; 
  onAddToList: (movie: Movie) => void;
  isInList: boolean;
  onInfoClick: (movie: Movie) => void;
  key?: React.Key;
}) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.1, zIndex: 50 }}
      className="relative min-w-[180px] md:min-w-[200px] h-[110px] md:h-[130px] cursor-pointer group rounded bg-[#1a1a1a] border border-white/5 shadow-2xl overflow-hidden"
    >
      <img
        src={movie.image}
        alt={movie.title}
        className="w-full h-full object-cover transition-transform duration-300 group-hover:brightness-50"
        referrerPolicy="no-referrer"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-2 md:p-3">
        <div className="flex justify-between items-center gap-2">
          <span 
            onClick={() => onInfoClick(movie)}
            className="text-[10px] md:text-xs font-bold text-gray-100 truncate hover:underline"
          >
            {movie.title}
          </span>
          <div className="flex gap-1">
            <a
              href={movie.videoUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-5 h-5 bg-white rounded-full flex items-center justify-center text-black hover:bg-gray-200 transition-colors"
            >
              <Play size={10} fill="currentColor" />
            </a>
            <button
              onClick={(e) => {
                e.preventDefault();
                onAddToList(movie);
              }}
              className={cn(
                "w-5 h-5 rounded-full border flex items-center justify-center transition-colors",
                isInList ? "bg-green-600 border-green-600 text-white" : "border-white/40 text-white hover:border-white"
              )}
            >
              {isInList ? <Check size={10} /> : <span className="text-[10px] font-bold">+</span>}
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function MovieRow({ 
  title, 
  movies, 
  onAddToList, 
  listIds,
  onInfoClick
}: { 
  title: string; 
  movies: Movie[]; 
  onAddToList: (movie: Movie) => void;
  listIds: string[];
  key?: number | string;
  onInfoClick: (movie: Movie) => void;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const { scrollLeft, clientWidth } = scrollRef.current;
      const scrollTo = direction === 'left' 
        ? scrollLeft - clientWidth * 0.8 
        : scrollLeft + clientWidth * 0.8;
      
      scrollRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  if (movies.length === 0) return null;

  return (
    <div className="py-2 md:py-6 relative group">
      <h2 className="text-lg font-semibold mb-3 px-4 md:px-10 text-gray-100">
        {title}
      </h2>
      
      <div className="relative overflow-hidden">
        <button 
          onClick={() => scroll('left')}
          className="absolute left-0 top-0 bottom-0 z-40 bg-black/50 p-2 opacity-0 group-hover:opacity-100 transition-opacity hidden md:flex items-center"
        >
          <ChevronLeft size={32} />
        </button>
        
        <div 
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto no-scrollbar scroll-smooth px-4 md:px-10 pb-4"
        >
          {movies.map((movie) => (
            <MovieCard 
              key={movie.id} 
              movie={movie} 
              onAddToList={onAddToList}
              isInList={listIds.includes(movie.id)}
              onInfoClick={onInfoClick}
            />
          ))}
        </div>

        <button 
          onClick={() => scroll('right')}
          className="absolute right-0 top-0 bottom-0 z-40 bg-black/50 p-2 opacity-0 group-hover:opacity-100 transition-opacity hidden md:flex items-center"
        >
          <ChevronRight size={40} />
        </button>
      </div>
    </div>
  );
}

// --- Main App ---

export default function App() {
  const [scrolled, setScrolled] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [myList, setMyList] = useState<string[]>([]);
  const [currentTab, setCurrentTab] = useState<'home' | 'tv'| 'movies' | 'popular' | 'mylist'>('home');
  const [selectedMovieForInfo, setSelectedMovieForInfo] = useState<Movie | null>(null);

  // Profile States
  const [activeProfile, setActiveProfile] = useState<UserProfile | null>(null);
  const [profiles, setProfiles] = useState<UserProfile[]>(DEFAULT_PROFILES);
  const [isManageMode, setIsManageMode] = useState(false);
  const [editingProfile, setEditingProfile] = useState<UserProfile | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleAddToList = (movie: Movie) => {
    setMyList(prev => 
      prev.includes(movie.id) ? prev.filter(id => id !== movie.id) : [...prev, movie.id]
    );
  };

  const handleImageUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && editingProfile) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditingProfile({ ...editingProfile, avatar: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const saveProfileEdit = () => {
    if (editingProfile) {
      setProfiles(prev => prev.map(p => p.id === editingProfile.id ? editingProfile : p));
      setEditingProfile(null);
    }
  };

  const filteredMovies = MOVIES.filter(movie => 
    movie.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const featuredMovie = MOVIES[0];

  const categories = useMemo(() => [
    { title: 'Trending Now', filter: (m: Movie) => m.trending },
    { title: 'Action Thrillers', filter: (m: Movie) => m.category === 'Action' },
    { title: 'Sci-Fi Hits', filter: (m: Movie) => m.category === 'Sci-Fi' },
    { title: 'Horror', filter: (m: Movie) => m.category === 'Horror' },
  ], []);

  const getFilteredCategories = () => {
    if (currentTab === 'tv') {
      return [{ title: 'Popular TV Shows', filter: (m: Movie) => m.type === 'tv' }];
    }
    if (currentTab === 'movies') {
      return [{ title: 'Blockbuster Movies', filter: (m: Movie) => m.type === 'movie' }];
    }
    if (currentTab === 'popular') {
      return [{ title: 'Popular on MovieFlix', filter: (m: Movie) => m.isPopular }];
    }
    return categories;
  };

  const currentCategories = getFilteredCategories();
  const myMoviesList = MOVIES.filter(m => myList.includes(m.id));

  // --- Profile Selection View ---
  if (!activeProfile) {
    return (
      <div className="min-h-screen bg-netflix-black flex flex-col items-center justify-center p-6 select-none font-sans">
        <AnimatePresence mode="wait">
          {!editingProfile ? (
            <motion.div 
              key="picker"
              initial={{ opacity: 0, scale: 1.1 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="flex flex-col items-center"
            >
              <h1 className="text-3xl md:text-5xl font-medium text-white mb-12">
                {isManageMode ? 'Manage Profiles:' : "Who's watching?"}
              </h1>

              <div className="flex flex-wrap justify-center gap-4 md:gap-8 mb-12">
                {profiles.map(p => (
                  <ProfileCard 
                    key={p.id} 
                    profile={p} 
                    isManageMode={isManageMode}
                    onSelect={setActiveProfile}
                    onEdit={setEditingProfile}
                  />
                ))}
                
                {!isManageMode && (
                  <div className="flex flex-col items-center gap-4 group">
                    <button 
                      onClick={() => setIsManageMode(true)}
                      className="w-24 h-24 md:w-32 md:h-32 rounded-md border-2 border-transparent flex items-center justify-center bg-transparent group-hover:bg-netflix-red hover:border-white transition-all transform hover:scale-105"
                    >
                      <Plus size={48} className="text-gray-400 group-hover:text-white" />
                    </button>
                    <span className="text-gray-400 group-hover:text-white text-lg md:text-xl transform transition-colors">
                      Add Profile
                    </span>
                  </div>
                )}
              </div>

              <button 
                onClick={() => setIsManageMode(!isManageMode)}
                className={cn(
                   "px-8 py-2 border border-gray-600 text-gray-500 text-lg uppercase tracking-widest hover:border-white hover:text-white transition-all",
                   isManageMode && "border-white text-white bg-white/10"
                )}
              >
                {isManageMode ? 'Done' : 'Manage Profiles'}
              </button>
            </motion.div>
          ) : (
            <motion.div 
              key="editor"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="w-full max-w-2xl px-6"
            >
              <h1 className="text-4xl md:text-6xl font-medium text-white mb-8">Edit Profile</h1>
              
              <div className="flex flex-col md:flex-row gap-8 py-8 border-t border-b border-gray-700 mb-8">
                <div className="relative w-32 h-32 md:w-40 md:h-40 rounded-md overflow-hidden shrink-0">
                  <img src={editingProfile.avatar} className="w-full h-full object-cover" />
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute bottom-2 left-2 p-2 bg-black/60 rounded-full text-white hover:bg-black/80 transition-colors"
                  >
                    <Camera size={20} />
                  </button>
                  <input 
                    type="file" 
                    className="hidden" 
                    ref={fileInputRef} 
                    accept="image/*"
                    onChange={handleImageUpload}
                  />
                </div>
                
                <div className="flex flex-col gap-6 flex-1">
                  <input 
                    type="text" 
                    value={editingProfile.name}
                    onChange={(e) => setEditingProfile({ ...editingProfile, name: e.target.value })}
                    className="bg-gray-600 text-white px-4 py-3 text-xl outline-none focus:bg-gray-500 transition-colors"
                    placeholder="Name"
                  />
                  
                  <div className="space-y-2">
                    <p className="text-gray-400 text-lg uppercase tracking-wide">Language:</p>
                    <select className="bg-black text-white border border-white/20 px-3 py-1.5 w-full md:w-48 outline-none">
                      <option>English</option>
                      <option>Spanish</option>
                      <option>French</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={saveProfileEdit}
                  className="bg-white text-black px-8 py-2 font-bold text-lg hover:bg-netflix-red hover:text-white transition-all uppercase tracking-widest"
                >
                  Save
                </button>
                <button 
                  onClick={() => setEditingProfile(null)}
                  className="px-8 py-2 border border-gray-600 text-gray-500 text-lg hover:border-white hover:text-white transition-all uppercase tracking-widest"
                >
                  Cancel
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  // --- Main App Dashboard ---
  return (
    <div className="min-h-screen bg-netflix-black selection:bg-netflix-red selection:text-white">
      {/* Navigation */}
      <nav className={cn(
        "fixed top-0 w-full z-50 flex items-center justify-between px-4 md:px-10 h-16 transition-all duration-300 border-b",
        scrolled 
          ? "bg-black/60 backdrop-blur-xl border-white/10" 
          : "bg-black/40 backdrop-blur-md border-transparent"
      )}>
        <div className="flex items-center gap-4 md:gap-10">
          <h1 
            onClick={() => setCurrentTab('home')}
            className="text-netflix-red font-display font-extrabold text-xl md:text-3xl cursor-pointer tracking-tighter"
          >
            MOVIEFLIX
          </h1>
          <ul className="hidden md:flex items-center gap-6 text-sm text-gray-200 font-medium">
            <li 
              className={cn("cursor-pointer transition-colors", currentTab === 'home' ? "text-white font-bold" : "hover:text-gray-400")}
              onClick={() => { setCurrentTab('home'); setSearchQuery(''); }}
            >
              Home
            </li>
            <li 
              className={cn("cursor-pointer transition-colors", currentTab === 'tv' ? "text-white font-bold" : "hover:text-gray-400")}
              onClick={() => { setCurrentTab('tv'); setSearchQuery(''); }}
            >
              TV Shows
            </li>
            <li 
              className={cn("cursor-pointer transition-colors", currentTab === 'movies' ? "text-white font-bold" : "hover:text-gray-400")}
              onClick={() => { setCurrentTab('movies'); setSearchQuery(''); }}
            >
              Movies
            </li>
            <li 
              className={cn("cursor-pointer transition-colors", currentTab === 'popular' ? "text-white font-bold" : "hover:text-gray-400")}
              onClick={() => { setCurrentTab('popular'); setSearchQuery(''); }}
            >
              New & Popular
            </li>
            <li 
              className={cn(
                "cursor-pointer transition-colors",
                currentTab === 'mylist' ? "text-white font-bold underline underline-offset-8" : "hover:text-gray-400"
              )}
              onClick={() => { setCurrentTab('mylist'); setSearchQuery(''); }}
            >
              My List
            </li>
          </ul>
        </div>

        <div className="flex items-center gap-4 md:gap-8 text-gray-200">
          <div className="relative flex items-center">
            <button 
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className="p-1 hover:text-white transition-colors"
            >
              <Search size={20} />
            </button>
            <AnimatePresence>
              {isSearchOpen && (
                <motion.div
                  initial={{ width: 0, opacity: 0 }}
                  animate={{ width: 220, opacity: 1 }}
                  exit={{ width: 0, opacity: 0 }}
                  className="absolute right-0 top-0 bottom-0 bg-black/60 backdrop-blur-md border border-white/20 flex items-center px-3 rounded-sm"
                >
                  <Search size={16} className="text-gray-400" />
                  <input
                    autoFocus
                    type="text"
                    placeholder="Titles, people, genres..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-transparent border-none outline-none text-xs ml-2 w-full placeholder:text-gray-500"
                  />
                  <button onClick={() => { setIsSearchOpen(false); setSearchQuery(''); }}>
                    <X size={14} />
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          <Bell size={22} className="cursor-pointer hover:text-white transition-colors" />
          
          {/* Profile Menu */}
          <div className="relative group/profile">
            <div className="flex items-center gap-2 cursor-pointer">
              <img 
                src={activeProfile.avatar} 
                alt="Profile" 
                className="w-8 h-8 rounded-md border border-transparent hover:border-white transition-all"
              />
              <ChevronRight size={16} className="transition-transform group-hover/profile:rotate-90 hidden md:block" />
            </div>
            
            <div className="absolute right-0 top-full pt-4 hidden group-hover/profile:block">
              <div className="bg-black/90 backdrop-blur-xl border border-white/10 p-4 w-48 rounded-sm shadow-2xl flex flex-col gap-4">
                <div className="flex flex-col gap-2">
                  {profiles.filter(p => p.id !== activeProfile.id).map(p => (
                    <div 
                      key={p.id} 
                      onClick={() => setActiveProfile(p)}
                      className="flex items-center gap-3 hover:underline cursor-pointer text-sm"
                    >
                      <img src={p.avatar} className="w-8 h-8 rounded-md" />
                      <span>{p.name}</span>
                    </div>
                  ))}
                  <div 
                    onClick={() => { setActiveProfile(null); setIsManageMode(true); }}
                    className="flex items-center gap-3 hover:underline cursor-pointer text-sm pt-2 border-t border-white/10"
                  >
                    <Edit2 size={16} />
                    <span>Manage Profiles</span>
                  </div>
                </div>
                <button 
                  onClick={() => setActiveProfile(null)}
                  className="text-center text-sm font-bold border-t border-white/10 pt-4 hover:underline"
                >
                  Sign out of MovieFlix
                </button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Content */}
      {currentTab === 'home' && !searchQuery && (
        <header className="relative w-full h-[60vh] md:h-screen overflow-hidden">
          <div className="absolute inset-0">
            <img 
              src={featuredMovie.image}
              alt={featuredMovie.title}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            {/* Design gradients */}
            <div className="absolute inset-0 bg-gradient-to-r from-black via-transparent to-black/20" />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent to-netflix-black" />
            {/* Frosted glow element from design */}
            <div className="absolute right-0 top-0 w-2/3 h-full bg-[#1a1a1a] opacity-40 blur-3xl rounded-full translate-x-1/2 -translate-y-1/2" />
          </div>

          <div className="relative h-full flex flex-col justify-center px-4 md:px-10 pt-16">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="max-w-xl"
            >
              <div className="flex items-center gap-2 mb-2">
                <span className="text-netflix-red font-bold text-xs tracking-widest uppercase">Featured</span>
              </div>
              <h1 className="text-5xl md:text-7xl font-bold mb-4 tracking-tighter uppercase leading-tight">
                {featuredMovie.title}
              </h1>
              <p className="text-gray-300 text-sm md:text-base leading-relaxed mb-6 max-w-lg">
                {featuredMovie.description}
              </p>
              <div className="flex gap-3">
                <a 
                  href={featuredMovie.videoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 bg-white text-black px-6 md:px-8 py-2 rounded font-bold text-sm hover:bg-white/90 transition-all active:scale-95 shadow-lg shadow-white/5"
                >
                  <Play size={20} fill="currentColor" /> Play
                </a>
                <button 
                  onClick={() => setSelectedMovieForInfo(featuredMovie)}
                  className="flex items-center gap-2 bg-gray-500/40 backdrop-blur-md text-white px-6 md:px-8 py-2 rounded font-bold text-sm hover:bg-gray-500/60 transition-all active:scale-95 shadow-lg shadow-black/20"
                >
                  <Info size={20} /> More Info
                </button>
              </div>
            </motion.div>
          </div>
        </header>
      )}

      {/* Content Main */}
      <main className={cn(
        "relative z-10",
        currentTab !== 'home' || searchQuery ? "pt-24 min-h-[60vh]" : "-mt-20 md:-mt-32"
      )}>
        {currentTab === 'mylist' ? (
          <div className="px-4 md:px-12">
            <h1 className="text-3xl font-bold mb-8">My List</h1>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 pb-20">
              {myMoviesList.map(movie => (
                <MovieCard 
                  key={movie.id} 
                  movie={movie} 
                  onAddToList={handleAddToList}
                  isInList={true}
                  onInfoClick={setSelectedMovieForInfo}
                />
              ))}
              {myMoviesList.length === 0 && (
                <div className="col-span-full py-20 text-center text-gray-500">
                  <p className="text-xl">Your list is currently empty.</p>
                  <button 
                    onClick={() => setCurrentTab('home')}
                    className="mt-4 text-netflix-red font-bold hover:underline"
                  >
                    Browse movies
                  </button>
                </div>
              )}
            </div>
          </div>
        ) : searchQuery ? (
          <div className="px-4 md:px-12">
            <h1 className="text-2xl text-gray-400 mb-8">
              Search results for: <span className="text-white">"{searchQuery}"</span>
            </h1>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 pb-20">
              {filteredMovies.map(movie => (
                <MovieCard 
                  key={movie.id} 
                  movie={movie} 
                  onAddToList={handleAddToList}
                  isInList={myList.includes(movie.id)}
                  onInfoClick={setSelectedMovieForInfo}
                />
              ))}
              {filteredMovies.length === 0 && (
                <div className="col-span-full py-20 text-center text-gray-500">
                  <p className="text-xl">No movies found matching your search.</p>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {currentCategories.map((cat, idx) => (
              <MovieRow 
                key={idx} 
                title={cat.title} 
                movies={MOVIES.filter(cat.filter)} 
                onAddToList={handleAddToList}
                listIds={myList}
                onInfoClick={setSelectedMovieForInfo}
              />
            ))}
          </div>
        )}
      </main>

      {/* More Info Modal */}
      <AnimatePresence>
        {selectedMovieForInfo && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center px-4 py-8">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedMovieForInfo(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div
              layoutId={`movie-modal-${selectedMovieForInfo.id}`}
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-3xl bg-netflix-black rounded-xl overflow-hidden shadow-2xl border border-white/10"
            >
              <button 
                onClick={() => setSelectedMovieForInfo(null)}
                className="absolute top-4 right-4 z-50 p-2 bg-black/60 rounded-full text-white hover:bg-black/80 transition-colors"
              >
                <X size={20} />
              </button>
              
              <div className="relative h-64 md:h-96 text-white font-sans">
                <img 
                  src={selectedMovieForInfo.image} 
                  alt={selectedMovieForInfo.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-netflix-black to-transparent" />
                <div className="absolute bottom-10 left-10 p-4">
                  <h2 className="text-4xl font-bold mb-4">{selectedMovieForInfo.title}</h2>
                  <div className="flex gap-4">
                    <a 
                      href={selectedMovieForInfo.videoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 bg-white text-black px-6 py-2 rounded font-bold hover:bg-gray-200 transition-colors"
                    >
                      <Play size={20} fill="currentColor" /> Play
                    </a>
                    <button 
                      onClick={() => handleAddToList(selectedMovieForInfo)}
                      className="p-2 border border-white/50 rounded-full hover:bg-white/10 transition-colors"
                    >
                      {myList.includes(selectedMovieForInfo.id) ? <Check /> : <Plus />}
                    </button>
                  </div>
                </div>
              </div>

              <div className="p-6 md:p-10 grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="col-span-2 space-y-4">
                  <div className="flex items-center gap-2 text-green-500 font-bold">
                    <span>98% Match</span>
                    <span className="text-gray-500 border border-gray-500 px-1 text-[10px]">HD</span>
                    <span className="text-gray-400 text-sm">2024</span>
                  </div>
                  <p className="text-lg text-gray-200 leading-relaxed font-sans">
                    {selectedMovieForInfo.description}
                  </p>
                </div>
                <div className="space-y-4 text-sm font-sans">
                  <div>
                    <span className="text-gray-500">Cast: </span>
                    <span className="text-gray-200">Featured Artists</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Genres: </span>
                    <span className="text-gray-200">{selectedMovieForInfo.genre.join(', ')}</span>
                  </div>
                  <div>
                    <span className="text-gray-500">This show is: </span>
                    <span className="text-gray-200">Exciting, Action-Packed</span>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <footer className="bg-black/40 backdrop-blur-md px-4 md:px-10 py-12 border-t border-white/10 mt-20 font-sans">
        <div className="flex flex-col md:flex-row justify-between items-start gap-8">
          <div className="space-y-6">
            <div className="flex gap-6 text-white/60">
              <Facebook className="cursor-pointer hover:text-white" size={20} />
              <Instagram className="cursor-pointer hover:text-white" size={20} />
              <Twitter className="cursor-pointer hover:text-white" size={20} />
              <Youtube className="cursor-pointer hover:text-white" size={20} />
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-x-12 gap-y-2 text-[10px] text-gray-500">
              <a href="#" className="hover:underline">Audio Description</a>
              <a href="#" className="hover:underline">Help Center</a>
              <a href="#" className="hover:underline">Gift Cards</a>
              <a href="#" className="hover:underline">Media Center</a>
              <a href="#" className="hover:underline">Investor Relations</a>
              <a href="#" className="hover:underline">Jobs</a>
              <a href="#" className="hover:underline">Terms of Use</a>
              <a href="#" className="hover:underline">Privacy</a>
            </div>
            <p className="text-[9px] text-gray-600 uppercase tracking-wider">© 1997-2024 MovieFlix, Inc.</p>
          </div>
          
          <div className="border border-gray-600 px-3 py-1.5 text-[10px] text-gray-500 uppercase cursor-pointer hover:text-gray-300 transition-colors">
            Service Code
          </div>
        </div>
      </footer>
    </div>
  );
}
